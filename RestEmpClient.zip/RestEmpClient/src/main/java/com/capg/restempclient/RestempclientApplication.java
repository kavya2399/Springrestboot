package com.capg.restempclient;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RestempclientApplication {

	public static void main(String[] args) {
		SpringApplication.run(RestempclientApplication.class, args);
	}

}
