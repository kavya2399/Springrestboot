package com.capg.restempclient.controller;

import org.springframework.http.HttpEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.servlet.ModelAndView;

import com.capg.restempclient.model.Employee;
//import org.springframework.web.bind.annotation.RestController;
@Controller
public class RestClientController {

	@RequestMapping("/")
	public String getHome() {
		return "welcome";
		
	}
	@RequestMapping("/addEmp")
	public String addEmployee() {
		return "addEmp";
	}
	/*@RequestMapping(value="/addEmp", method=RequestMethod.POST)
	public String addEmp() {
		return "addEmp";
		String url="http://localhost:3456/employees";
		RestTemplate template =new RestTemplate();
		HttpEntity<Employee>request=new HttpEntity<Employee>(emp);
		String message=template.postForObject(url,request,String.class)
			System.out.println("response from rest" +message);
		ModelAndView mv=new ModelAndView();*/
		
	}

