package com.capg.sharetrading;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SharetradingApplication {

	public static void main(String[] args) {
		SpringApplication.run(SharetradingApplication.class, args);
	}

}
