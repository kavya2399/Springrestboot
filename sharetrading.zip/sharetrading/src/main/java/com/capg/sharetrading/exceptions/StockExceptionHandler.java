package com.capg.sharetrading.exceptions;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;



public class StockExceptionHandler {

	@ControllerAdvice
	public class StocktExceptionHandler {
	   @ExceptionHandler(StockException.class)
		public ResponseEntity <String> handleException(Exception ex){
			return new ResponseEntity <String> (" Please Enter an valid one : "+ex.getMessage(), HttpStatus.CONFLICT);
			
		}
	}
	}
