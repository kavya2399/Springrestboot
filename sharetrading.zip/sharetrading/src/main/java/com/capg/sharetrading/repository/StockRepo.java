package com.capg.sharetrading.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.capg.sharetrading.model.Stock;

@Repository
public interface StockRepo  extends JpaRepository<Stock, String>{

	Optional<Stock> findAllById(String id);

	void deleteById(int id);

}
